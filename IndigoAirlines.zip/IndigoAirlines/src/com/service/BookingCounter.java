package com.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.model.Booking;
import com.model.Flight;

public class BookingCounter implements Indigo {
	
	Scanner s=new Scanner(System.in);
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

	@Override
	public Booking bookFlight(Flight f) {
		
		System.out.println("Enter number of seats to book: ");
		int noOfSeats = s.nextInt();
		
		// Calculate total amount
		float totalAmount = noOfSeats * f.getTicketPrice();
		
		// Create a new booking
		Booking booking = new Booking();
		booking.setBookingId((int)(Math.random() * 10000)); // Generating a random booking ID
		booking.setBookingTime(LocalDateTime.now());
		booking.setNoOfSeats(noOfSeats);
		booking.setF(f);
		booking.setBookingAmt(totalAmount);
		
		System.out.println("Booking successful! Your total amount is: " + totalAmount);
		//System.out.println("Booking ID: " + booking.getBookingId());
		
		return booking;
	}

	@Override
	public void getstatus(Booking b) {
		System.out.printf("%-10d | %-30s | %-10s | %-10s | %-15s | %-10.2f%n",b.getBookingId(),b.getBookingTime().format(formatter),b.getF().getFrom(),b.getF().getTo(),b.getNoOfSeats(),b.getBookingAmt());

		
	}
	
	

}
