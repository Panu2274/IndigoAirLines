package com.user;

import java.util.Comparator;
import com.model.Flight;


public class EarlyTimeSort implements Comparator<Flight> {

    @Override
    public int compare(Flight o1, Flight o2) {
        // Compare the LocalDateTime fields of two Flight objects
        return o1.getDt().compareTo(o2.getDt());
    }
}
