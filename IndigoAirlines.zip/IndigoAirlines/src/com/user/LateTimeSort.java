package com.user;

import java.util.Comparator;

import com.model.Flight;

public class LateTimeSort implements Comparator<Flight> {

    @Override
    public int compare(Flight o1, Flight o2) {
        // Compare the LocalDateTime fields of two Flight objects
        return o2.getDt().compareTo(o1.getDt());
    }
}