package com.user;

import java.util.Comparator;

import com.model.Flight;

public class OriginalSort implements Comparator<Flight>{

	@Override
	public int compare(Flight o1, Flight o2) {
		if(o1.getId()>o2.getId()){
			return 1;
		}else if(o1.getId()<o2.getId()){
			return -1;
		}
		else {
		return 0;
	}
	
	}

}
