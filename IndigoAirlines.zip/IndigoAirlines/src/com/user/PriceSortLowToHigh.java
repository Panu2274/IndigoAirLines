package com.user;

import java.util.Comparator;

import com.model.Flight;

public class PriceSortLowToHigh implements Comparator<Flight> {

	@Override
	public int compare(Flight o1, Flight o2) {
		if(o1.getTicketPrice()>o2.getTicketPrice()) {
			return 1;
		}else if(o1.getTicketPrice()<o2.getTicketPrice()){
			return -1;
		}
		else {
		return 0;
		}
	}
}
