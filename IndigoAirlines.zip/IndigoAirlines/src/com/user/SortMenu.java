package com.user;

import java.time.format.DateTimeFormatter;
import java.util.Collections;

import java.util.List;
import java.util.Scanner;

import com.model.Flight;

public class SortMenu {
	
	
	public static void displayFlightsByPriceRange(List<Flight> flights, float minPrice, float maxPrice, DateTimeFormatter formatter) {
	    System.out.println("\nFlights available within the price range: " + minPrice + " - " + maxPrice);

	    boolean flightFound = false;  // Flag to check if any flight is found

	    // Loop through flights to check if any flight meets the price range
	    for (Flight flight : flights) {
	        if (flight.getTicketPrice() >= minPrice && flight.getTicketPrice() <= maxPrice) {
	            if (!flightFound) {
	                // Print table header only once when the first flight is found
	                System.out.printf("%-10s | %-10s | %-10s | %-20s | %-10s%n", "Flight ID", "From", "To", "Departure Time", "Price");
	                System.out.println("---------------------------------------------------------------");
	                flightFound = true;  // Flight found, set the flag to true
	            }
	            // Print flight details
	            System.out.printf("%-10d | %-10s | %-10s | %-20s | %-10.2f%n", 
	                flight.getId(), 
	                flight.getFrom(), 
	                flight.getTo(), 
	                flight.getDt().format(formatter), 
	                flight.getTicketPrice());
	        }
	    }

	    // If no flight is found within the price range, display a message
	    if (!flightFound) {
	        System.out.println("No flights available within the specified price range.");
	    }
	}


	public static void sortMenu(List<Flight> flights,Scanner sc,DateTimeFormatter formatter) {
	

	int filter;
	do {
		System.out.println("\n\nFilter:\n1.Price-Low to high\n2.Price-High to low\n3.Early departure\n4.Late departure\n5.Popular\n6.Back to main menu\n\n");
        System.out.println("Enter your choice:");
        String ans=null;
		filter=sc.nextInt();
		switch (filter) {
		case 1: System.out.println("Do you want to display flights in specific price range?");
				 ans=sc.next();
				if(ans.equalsIgnoreCase("yes")) {
					System.out.println("\n\nEnter minimum price: ");
			        float minPrice = sc.nextFloat();
			        System.out.println("Enter maximum price: ");
			        float maxPrice = sc.nextFloat();
			        displayFlightsByPriceRange(flights, minPrice, maxPrice, formatter);
				}else {
		
			PriceSortLowToHigh lw=new PriceSortLowToHigh();
			Collections.sort(flights,lw);
			 System.out.println("\n--------------------------------------------------------------------------");
              System.out.printf("%-10s | %-10s | %-10s | %-20s | %-10s%n", "Flight ID", "From", "To", "Date & Time", "Price");
              System.out.println("--------------------------------------------------------------------------");
              for (Flight flight : flights) {
                  System.out.printf("%-10d | %-10s | %-10s | %-20s | %-10.2f%n", 
                                    flight.getId(), flight.getFrom(), flight.getTo(), flight.getDt().format(formatter), flight.getTicketPrice());
              }
				}
              break;
		case 2: System.out.println("Do you want to display flights in specific price range?");
		 		ans=sc.next();
		if(ans.equalsIgnoreCase("yes")) {
			System.out.println("\n\nEnter minimum price: ");
	        float minPrice = sc.nextFloat();
	        System.out.println("Enter maximum price: ");
	        float maxPrice = sc.nextFloat();
	        displayFlightsByPriceRange(flights, minPrice, maxPrice, formatter);
		}else {
			PriceSortHighToLow h=new PriceSortHighToLow();
			Collections.sort(flights,h);
			 System.out.println("\n--------------------------------------------------------------------------");
              System.out.printf("%-10s | %-10s | %-10s | %-20s | %-10s%n", "Flight ID", "From", "To", "Date & Time", "Price");
              System.out.println("--------------------------------------------------------------------------");
              for (Flight flight : flights) {
                  System.out.printf("%-10d | %-10s | %-10s | %-20s | %-10.2f%n", 
                                    flight.getId(), flight.getFrom(), flight.getTo(), flight.getDt().format(formatter), flight.getTicketPrice());
              }
		}
              break;
		case 3:
			EarlyTimeSort e=new EarlyTimeSort();
			Collections.sort(flights,e);
	
			System.out.println("\n--------------------------------------------------------------------------");
              System.out.printf("%-10s | %-10s | %-10s | %-20s | %-10s%n", "Flight ID", "From", "To", "Date & Time", "Price");
              System.out.println("--------------------------------------------------------------------------");
              for (Flight flight : flights) {
                  System.out.printf("%-10d | %-10s | %-10s | %-20s | %-10.2f%n", 
                                    flight.getId(), flight.getFrom(), flight.getTo(), flight.getDt().format(formatter), flight.getTicketPrice());
              }
              break;
		case 4:
			LateTimeSort lt=new LateTimeSort();
			Collections.sort(flights,lt);
			System.out.println("\n--------------------------------------------------------------------------");
              System.out.printf("%-10s | %-10s | %-10s | %-20s | %-10s%n", "Flight ID", "From", "To", "Date & Time", "Price");
              System.out.println("--------------------------------------------------------------------------");
              for (Flight flight : flights) {
                  System.out.printf("%-10d | %-10s | %-10s | %-20s | %-10.2f%n", 
                                    flight.getId(), flight.getFrom(), flight.getTo(), flight.getDt().format(formatter), flight.getTicketPrice());
              }
              break;
			
		case 5:
			  OriginalSort o=new OriginalSort();
			  Collections.sort(flights,o);
			  System.out.println("\n--------------------------------------------------------------------------");
              System.out.printf("%-10s | %-10s | %-10s | %-20s | %-10s%n", "Flight ID", "From", "To", "Date & Time", "Price");
              System.out.println("--------------------------------------------------------------------------");
              for (Flight flight : flights) {
                  System.out.printf("%-10d | %-10s | %-10s | %-20s | %-10.2f%n", 
                                    flight.getId(), flight.getFrom(), flight.getTo(), flight.getDt().format(formatter), flight.getTicketPrice());
              }
              break;
		case 6:
			break;
			
		}
	}while(filter!=6);
}
}
