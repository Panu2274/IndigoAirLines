package com.user;

import java.io.File;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.model.Booking;
import com.model.Flight;
import com.service.BookingCounter;

public class Test {

    public static void main(String[] args) throws IOException{

        try (Scanner sc = new Scanner(System.in)) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            BookingCounter bookingCounter = new BookingCounter();
            Booking b=null;
   
            List<Flight> flights = new ArrayList<>();

            Flight flight1 = new Flight();
            flight1.setId(101);
            flight1.setFrom("Mumbai");
            flight1.setTo("Delhi");
            flight1.setDt(LocalDateTime.of(2024, 9, 30, 12, 0));
            flight1.setTicketPrice(5000.0f);
            flights.add(flight1);

            Flight flight2 = new Flight();
            flight2.setId(102);
            flight2.setFrom("Pune");
            flight2.setTo("Bangalore");
            flight2.setDt(LocalDateTime.of(2024, 10, 5, 15, 30));
            flight2.setTicketPrice(4000.0f);
            flights.add(flight2);

            Flight flight3 = new Flight();
            flight3.setId(103);
            flight3.setFrom("Hyderabad");
            flight3.setTo("Chennai");
            flight3.setDt(LocalDateTime.of(2024, 10, 12, 9, 45));
            flight3.setTicketPrice(3500.0f);
            flights.add(flight3);

            Flight flight4 = new Flight();
            flight4.setId(104);
            flight4.setFrom("Nashik");
            flight4.setTo("Pune");
            flight4.setDt(LocalDateTime.of(2024, 10, 1, 8, 45));
            flight4.setTicketPrice(3000.0f);
            flights.add(flight4);

            Flight flight5 = new Flight();
            flight5.setId(105);
            flight5.setFrom("Kolhapur");
            flight5.setTo("Pune");
            flight5.setDt(LocalDateTime.of(2024, 7, 22, 12, 00));
            flight5.setTicketPrice(4300.0f);
            flights.add(flight5);
            
            Flight flight6 = new Flight();
            flight6.setId(106);
            flight6.setFrom("Pune");
            flight6.setTo("Chennai");
            flight6.setDt(LocalDateTime.of(2024, 10, 12, 12, 50));
            flight6.setTicketPrice(6500.0f);
            flights.add(flight6);
            
            Flight flight7 = new Flight();
            flight7.setId(107);
            flight7.setFrom("Mumbai");
            flight7.setTo("Chennai");
            flight7.setDt(LocalDateTime.of(2024, 1, 12, 8, 45));
            flight7.setTicketPrice(7500.0f);
            flights.add(flight7);
            
            Flight flight8 = new Flight();
            flight8.setId(108);
            flight8.setFrom("Hyderabad");
            flight8.setTo("Jalgaon");
            flight8.setDt(LocalDateTime.of(2024, 1, 12, 2, 45 ));
            flight8.setTicketPrice(9500.0f);
            flights.add(flight8);

            // Display available flights in a formatted table
            System.out.println("*********************** Welcome To Indigo Airlines *************************");
            System.out.println();
            int ch;
            while(true) {
            	System.out.println("\nHey! I'm Jinny from Indigo Airlines....\nHow can I assist today...Here's a menu..\n");
            	System.out.println("\n1.Show Available flights\n2.Book flight\n3.Display booking details\n4.Print ticket\n5.Exit\nEnter your choice: ");
            	ch=sc.nextInt();
            	switch(ch) {
            	case 1:
            		SortMenu.sortMenu(flights, sc,formatter);
            		break;
            	case 2:
                    // Ask the user to enter flight ID
                    System.out.println("\nEnter the Flight ID you want to book: ");
                    int flightId = sc.nextInt();

                    // Search for the flight with the entered ID in the array
                    Flight selectedFlight = null;
                    for (Flight flight : flights) {
                        if (flight.getId() == flightId) {
                            selectedFlight = flight;
                            break;
                        }
                    }
                    // If flight is found, proceed with booking
                    if (selectedFlight != null) {
                    	b = bookingCounter.bookFlight(selectedFlight);
                    } else {
                        System.out.println("Invalid Flight ID. Please try again.");
                    }
                    break;
            	
            	case 3:
            		System.out.printf("%-10s | %-30s | %-10s | %-10s | %-15s | %-10s%n", "Booking ID", "Booking-Time", "From", "To", "No of Seats", "Amount");
            		System.out.println("-------------------------------------------------------------------------------------------------------");
                
            		bookingCounter.getstatus(b);
            		break;
            	
            	case 4:
            	    if (b != null) {
            	        // Create the ticket file
            	        File ticketFile = new File("C:\\Users\\HP\\eclipse-workspace\\IndigoAirlines\\src\\com\\user\\Ticket.txt");
            	       
            	        // Check if the file already exists, and create it if not
            	        if (!ticketFile.exists()) {
            	            ticketFile.createNewFile();
            	        }
            	        // Write the ticket details into the text file
            	        try (FileWriter writer = new FileWriter(ticketFile)) {
            	            writer.write("Ticket Status\n\n");
            	            
            	            // Format the booking details and write to file using String.format()
            	            String head = String.format("%-10s | %-30s | %-10s | %-10s | %-15s | %-10s%n", "Booking ID", "Booking-Time", "From", "To", "No of Seats", "Amount");
            	            String ticketDetails = String.format(
            	                "%-10d | %-30s | %-10s | %-10s | %-15d | %-10.2f%n",
            	                b.getBookingId(),
            	                b.getBookingTime().format(formatter),
            	                b.getF().getFrom(),
            	                b.getF().getTo(),
            	                b.getNoOfSeats(),
            	                b.getBookingAmt()
            	            );
            	            writer.write(head);
            	            writer.write(ticketDetails); 
            	           }

            	        System.out.println("Ticket status saved in text file: Ticket.txt");
            	    } else {
            	        System.out.println("No booking found. Please book a flight first.");
            	    }
            	    break;
	
            case 5:	
            		System.out.println("Thank you!");
            		System.exit(0);
        			break;
        			
            default:
            	System.out.println("Invalid choice...");
            	break;
            	
          }
        } 
        }catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
